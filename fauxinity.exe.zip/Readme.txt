 ,__                                 .           
 /  `   ___  ,   . _  .- ` , __   ` _/_   ,    . 
 |__   /   ` |   |  \,'  | |'  `. |  |    |    ` 
 |    |    | |   |  /\   | |    | |  |    |    | 
 |    `.__/| `._/| /  \  / /    | /  \__/  `---|.
 /                                         \___/ 

As seen on TV!

A new malware made by fr4ctalz.
I was planning on adding XP compatibility, but there was one issue preventing me from doing that.







































n17pro3426 if you are seeing this i wanna ask you a question
do you want to see my documentation for NtRaiseHardError codes?